import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Buzzwords from "./sections/Buzzwords";
import Nats from "./sections/Nats";
import Profile from "./sections/Profile";
import "./App.css";

function App() {
  const [selectedUser, setSelectedUser] = useState("");

  return (
    <div className="App">
      <Router>
        <header className="App-header">
          Natter
          <nav>
            <ul>
              <li>
                <Link to="/buzzwords">Buzzwords</Link>
              </li>
              <li>
                <Link to="/nats">Nats!</Link>
              </li>
              <li>
                <Link to="/profile">Profile</Link>
              </li>
            </ul>
          </nav>
        </header>
        <main>
          <Switch>
            <Route exact path="/buzzwords">
              <Buzzwords />
            </Route>

            <Route exact path="/nats">
              <Nats handleUserClick={setSelectedUser} />
            </Route>

            <Route exact path="/profile">
              <Profile />
            </Route>
            {/* <Profile username={selectedUser} /> */}
          </Switch>
        </main>
      </Router>
    </div>
  );
}

export default App;

/* <Router>
    <div>
      <Route exact path="/">
        <Home />
      </Route>
      <Route path="/news">
        <NewsFeed />
      </Route>
    </div>
  </Router>, */
